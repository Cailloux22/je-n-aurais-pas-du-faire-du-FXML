package com.example.javafx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class HelloController {

    int count =0;
    @FXML
    private Label welcomeText;
    @FXML
    private Label dcount;
    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");

        count++;
        dcount.setText(String.valueOf(count));
    }
}
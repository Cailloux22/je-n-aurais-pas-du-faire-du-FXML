package com.example.javafx;

public class Entreprise {
    private String nom;
    private String addresses;

    public Entreprise(String nom, String addresses) {
        this.nom = nom;
        this.addresses = addresses;
    }

    public String getNom() {
        return nom;
    }

    public String getAddresses() {
        return addresses;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setAddresses(String addresses) {
        this.addresses = addresses;
    }
}

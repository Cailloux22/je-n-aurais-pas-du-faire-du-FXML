package com.example.javafx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(new Pane());
        stage.setTitle("Hello!");
        ViewSwitcher ViewSwitcher = new ViewSwitcher(scene);
        ViewSwitcher.add("MAIN", FXMLLoader.load(getClass().getResource(View.MAIN.getFileName() )));
        ViewSwitcher.add("DOCUMENTS", FXMLLoader.load(getClass().getResource( View.DOCUMENTS.getFileName() )));
        ViewSwitcher.activate("MAIN");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
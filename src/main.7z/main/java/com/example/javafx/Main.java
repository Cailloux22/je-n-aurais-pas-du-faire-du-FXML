package com.example.javafx;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        FactureManager.start();
    }
}